// Name: Ana Oro
// File: main.cpp
// Class: COSC360 (a03q02)

#include <iostream>
int main()
{
    int s0 = 0, s1 = 0, s2 = 0;
    char input[1024];
    while (1)
    {
        std::cout << ">>> ";
// read string from keyboard and put into input array of characters
// if input is "" break the while loop
// perform computation here
        std::cout << "$s0: " << s0 << std::endl;
        std::cout << "$s1: " << s1 << std::endl;
        std::cout << "$s2: " << s2 << std::endl;
    }
    std::cout << "END";
    return 0;
}
